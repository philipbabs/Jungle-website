import { Cormorant_Garamond, Syne, IBM_Plex_Mono } from 'next/font/google'
import './globals.css'

const cormorant = Cormorant_Garamond({
  subsets: ['latin'],
  weight: ['300', '400', '600', '700'],
  style: ['normal', 'italic'],
  variable: '--font-cormorant',
})

const syne = Syne({
  subsets: ['latin'],
  weight: ['400', '600', '700', '800'],
  variable: '--font-syne',
})

const ibmMono = IBM_Plex_Mono({
  subsets: ['latin'],
  weight: ['400', '700'],
  variable: '--font-mono',
})

export const metadata = {
  title: "Jungle City — Nigeria's First Jungle Resort City",
  description:
    "A 200–500 acre master-planned nature resort and lifestyle community between Lagos, Ogun and Ibadan. Own a plot from ₦9M.",
  openGraph: {
    title: "Jungle City — Where the wild becomes a way of life.",
    description:
      "Nigeria's first jungle resort city. Adventure, eco-stays, and mixed-use plots from ₦9M.",
    type: 'website',
  },
}

export default function RootLayout({ children }) {
  return (
    <html lang="en" className={`${cormorant.variable} ${syne.variable} ${ibmMono.variable}`}>
      <body>{children}</body>
    </html>
  )
}
