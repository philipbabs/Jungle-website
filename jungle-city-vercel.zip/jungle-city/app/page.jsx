'use client'

import { useEffect, useRef, useState } from 'react'

/* ── DATA ── */
const EXPERIENCES = [
  { icon:'🏍️', name:'Quad Bikes & ATVs',        desc:'Guided and self-drive quad bike experiences across red Nigerian earth and purpose-built dirt tracks. Pure adrenaline.' },
  { icon:'🛝', name:'Zipline',                    desc:'Soar across the jungle canopy. A canopy-level experience that makes you see Nigeria differently.' },
  { icon:'⛺', name:'Dome Tent Stays',             desc:'Luxury glamping domes with full amenities and open-sky design. Sleep under the stars in the Nigerian bush.' },
  { icon:'🏖️', name:'Artificial Beach',           desc:'A beach experience in the middle of the forest. Swim, relax, and reset — without the Lagos traffic to the coast.' },
  { icon:'🔥', name:'Bonfire Nights',             desc:'Curated evening experiences around an open fire. The kind of night you talk about for months.' },
  { icon:'🥾', name:'Hiking & Treasure Hunt',     desc:'Guided nature trails with activity overlays. For groups, families, and adventurers who want more than a walk.' },
  { icon:'🎯', name:'Archery',                    desc:'Structured archery sessions with trained instructors. Beginners welcome. Competitive souls encouraged.' },
  { icon:'🌀', name:'The Maze',                   desc:'A navigational challenge for individuals and groups. Great for team events, families, and competitive friend groups.' },
  { icon:'🏡', name:'Cottages & Container Houses', desc:'Private jungle cottages and modern container house stays. Intimate, architectural, and deeply Nigerian.' },
]

const PHASES = [
  { num:'Phase 01', name:'Land & Plot Sales',      desc:'Master land secured. Survey and legal title completed. Mixed-use plots launched for sale. Phase 1 buyers locked in at ground-floor pricing.', time:'Months 1–12',  dot:'var(--lime)' },
  { num:'Phase 02', name:'Roads & Infrastructure', desc:'Internal road network, solar-hybrid power, water systems, perimeter security. The Jungle terrain shaped and landscaped. Jungle City takes physical form.', time:'Months 6–18',  dot:'var(--sage)' },
  { num:'Phase 03', name:'The Jungle Opens',       desc:'Dome tents, cottages, container houses, quad bikes, zipline, artificial beach, activities all live. Nigeria\'s first jungle resort city is open for business.', time:'Months 18–30', dot:'var(--amber)' },
  { num:'Phase 04', name:'Full City',              desc:'Swimming pool, gym, co-working, restaurant, conference hall, courts, mini mart, game house. A self-sustaining lifestyle community in full operation.', time:'Months 30–48', dot:'var(--gold)' },
]

const WHO = [
  { avatar:'✈️', name:'The Diaspora Investor',  role:'UK · US · Canada',                desc:"You've been meaning to invest back home for years. You want something credible, exciting, and with real upside. Jungle City is the Nigerian investment you've been waiting for — with the lifestyle bonus you can actually enjoy on visits home." },
  { avatar:'🏙️', name:'The Lagos High Earner',  role:'Professionals & Business Owners', desc:"You earn well, travel often, and you're tired of Lagos traffic and overpriced experiences. You want somewhere extraordinary that doesn't require a flight. Own the land. Come whenever you want. Watch it appreciate." },
  { avatar:'🤝', name:'The Corporate Booker',   role:'HR Directors & Company Owners',   desc:"You need a retreat that your team will actually talk about. Jungle City offers accommodation, adventure, conference facilities, and an experience that no Lagos hotel can match. Bring the team. Stay the weekend." },
]

/* ── REVEAL HOOK ── */
function useReveal() {
  useEffect(() => {
    const els = document.querySelectorAll('.reveal')
    const obs = new IntersectionObserver(entries => {
      entries.forEach(e => {
        if (e.isIntersecting) { e.target.classList.add('visible'); obs.unobserve(e.target) }
      })
    }, { threshold: 0.12 })
    els.forEach(el => obs.observe(el))
    return () => obs.disconnect()
  }, [])
}

/* ── MAIN PAGE ── */
export default function Page() {
  const [scrolled, setScrolled] = useState(false)
  const cursorRef = useRef(null)
  const ringRef   = useRef(null)
  const mx = useRef(0), my = useRef(0)
  const rx = useRef(0), ry = useRef(0)

  useReveal()

  /* Cursor */
  useEffect(() => {
    const move = e => {
      mx.current = e.clientX; my.current = e.clientY
      if (cursorRef.current) {
        cursorRef.current.style.left = e.clientX + 'px'
        cursorRef.current.style.top  = e.clientY + 'px'
      }
    }
    document.addEventListener('mousemove', move)
    let raf
    const anim = () => {
      rx.current += (mx.current - rx.current) * 0.12
      ry.current += (my.current - ry.current) * 0.12
      if (ringRef.current) {
        ringRef.current.style.left = rx.current + 'px'
        ringRef.current.style.top  = ry.current + 'px'
      }
      raf = requestAnimationFrame(anim)
    }
    raf = requestAnimationFrame(anim)
    return () => { document.removeEventListener('mousemove', move); cancelAnimationFrame(raf) }
  }, [])

  /* Nav scroll */
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  /* Particles */
  useEffect(() => {
    const container = document.getElementById('particles')
    if (!container) return
    for (let i = 0; i < 18; i++) {
      const p = document.createElement('div')
      p.className = 'particle'
      p.style.cssText = `
        left:${Math.random()*100}%;
        width:${Math.random()*3+1}px;
        height:${Math.random()*3+1}px;
        animation-duration:${8+Math.random()*12}s;
        animation-delay:${Math.random()*10}s;
      `
      container.appendChild(p)
    }
  }, [])

  return (
    <>
      {/* CURSOR */}
      <div className="cursor" ref={cursorRef} />
      <div className="cursor-ring" ref={ringRef} />

      {/* NAV */}
      <nav className={scrolled ? 'scrolled' : ''}>
        <a href="#" className="nav-logo">Jungle<span>City</span></a>
        <ul className="nav-links">
          {['concept','experience','invest','phases','contact'].map(id => (
            <li key={id}><a href={`#${id}`}>{id.charAt(0).toUpperCase()+id.slice(1)}</a></li>
          ))}
        </ul>
        <a href="#contact" className="nav-cta">Get a Plot</a>
      </nav>

      {/* ══ HERO ══ */}
      <section className="hero" id="hero">
        <div className="hero-bg" />
        <div id="particles" style={{position:'absolute',inset:0,pointerEvents:'none'}} />
        <div className="scroll-hint">
          <span>Scroll</span>
          <div className="scroll-line" />
        </div>
        <div className="hero-content">
          <p className="hero-eyebrow">Nigeria · Lagos–Ogun–Ibadan Corridor</p>
          <h1 className="hero-h1">
            <span className="green italic">Jungle</span><br />
            <span className="italic">City.</span>
          </h1>
          <p className="hero-tagline">Where the wild becomes a way of life.</p>
          <div className="hero-actions">
            <a href="#invest" className="btn-primary">Own a Plot</a>
            <a href="#experience" className="btn-outline">Explore the Jungle</a>
          </div>
        </div>
        <div className="hero-stats">
          {[['500','Acres Total'],['50','Jungle Acres'],['₦9M','Starting Plot Price'],['4','Development Phases']].map(([n,l]) => (
            <div key={l} className="hero-stat">
              <span className="hero-stat-n">{n}</span>
              <span className="hero-stat-l">{l}</span>
            </div>
          ))}
        </div>
      </section>

      {/* ══ CONCEPT ══ */}
      <section className="concept-section" id="concept">
        <span className="section-tag reveal">The Concept</span>
        <h2 className="section-title reveal reveal-delay-1">Two worlds.<br /><em>One address.</em></h2>
        <p className="section-body reveal reveal-delay-2">
          Jungle City is a 200–500 acre master-planned development nestled between Lagos, Ogun and Ibadan.
          At its heart is The Jungle — Nigeria's first nature adventure and eco-accommodation resort.
          Surrounding it: a mixed-use community of plots you can own, build on, and call home.
        </p>
        <div className="concept-grid">
          {[
            { icon:'🌿', title:'The Jungle', body:'A 20–50 acre nature adventure and eco-accommodation resort embedded within the larger land. Quad bikes, ziplines, dome tent stays, artificial beach, bonfire nights, archery, paint balling, mazes, and hiking — all on Nigerian soil. The heartbeat of everything.' },
            { icon:'🏙️', title:'Jungle City', body:'The broader master-planned community surrounding The Jungle. Mixed-use plots — residential and commercial — available for purchase. Buy early, watch your land appreciate with every phase delivered. This is the investment of the decade in the Lagos corridor.' },
          ].map((c,i) => (
            <div key={c.title} className={`concept-card reveal reveal-delay-${i+1}`}>
              <span className="concept-card-icon">{c.icon}</span>
              <h3>{c.title}</h3>
              <p>{c.body}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ══ EXPERIENCE ══ */}
      <section className="exp-section" id="experience">
        <span className="section-tag reveal">The Jungle Experience</span>
        <h2 className="section-title reveal reveal-delay-1">
          Everything you've been<br />flying abroad for. <em>Here.</em>
        </h2>
        <p className="section-body reveal reveal-delay-2">
          Nigeria has never had a destination like this. The Jungle brings the world-class adventure
          and eco-stay experience home — so you never have to leave to feel alive.
        </p>
        <div className="exp-grid">
          {EXPERIENCES.map((e,i) => (
            <div key={e.name} className={`exp-card reveal reveal-delay-${(i%3)+1}`}>
              <span className="exp-icon">{e.icon}</span>
              <p className="exp-name">{e.name}</p>
              <p className="exp-desc">{e.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ══ INVEST ══ */}
      <section className="inv-section" id="invest">
        <span className="section-tag reveal">Own a Piece</span>
        <h2 className="section-title reveal reveal-delay-1">
          The smartest land play<br />in Nigeria <em>right now.</em>
        </h2>
        <div className="inv-layout">
          <div>
            <p className="section-body reveal">
              Plot prices start at ₦9M in Phase 1 and increase by approximately 30% with each phase delivered.
              Every milestone we hit adds real, measurable value to your land. Early buyers win the most.
            </p>
            <div className="h-rule" />
            <div className="phase-appreciation reveal">
              {[['Phase 1 (Now)','₦9M',false],['Phase 2 (+30%)','₦11.7M',false],['Phase 3 (+69%)','₦15.2M',false],['Phase 4 (+119%)','₦19.7M',true]].map(([l,v,g]) => (
                <div key={l} className="phase-box">
                  <span className="phase-box-label">{l}</span>
                  <span className={`phase-box-val${g?' gold':''}`}>{v}</span>
                </div>
              ))}
            </div>
            <p style={{marginTop:'16px',fontFamily:'var(--font-mono)',fontSize:'10px',letterSpacing:'2px',color:'rgba(240,235,224,0.3)',lineHeight:'1.7'}}>
              Small plot (400sqm) appreciation example. C of O provided on all plots.
            </p>
          </div>
          <div className="plot-cards reveal">
            {[['Small Plot','400 sqm','Residential · Entry Investment','₦9M'],
              ['Medium Plot','700 sqm','Residential or Commercial','₦14M'],
              ['Large Plot','1,000 sqm','Premium · Commercial Potential','₦20M']].map(([type,size,sub,price]) => (
              <div key={type} className="plot-card">
                <div>
                  <span className="plot-type">{type}</span>
                  <p className="plot-name">{size}</p>
                  <p className="plot-size">{sub}</p>
                </div>
                <div>
                  <p className="plot-price">{price}</p>
                  <p className="plot-price-note">Phase 1 Price</p>
                </div>
              </div>
            ))}
            <a href="#contact" className="btn-primary" style={{display:'block',textAlign:'center',marginTop:'3px'}}>
              Reserve Your Plot →
            </a>
          </div>
        </div>
      </section>

      {/* ══ WHO ══ */}
      <section className="who-section">
        <span className="section-tag reveal">Who Jungle City Is For</span>
        <h2 className="section-title reveal reveal-delay-1">
          Built for the <em>bold.</em><br />Priced for <span className="g">the early.</span>
        </h2>
        <div className="who-grid">
          {WHO.map((w,i) => (
            <div key={w.name} className={`who-card reveal reveal-delay-${i+1}`}>
              <span className="who-avatar">{w.avatar}</span>
              <p className="who-name">{w.name}</p>
              <span className="who-role">{w.role}</span>
              <p className="who-desc">{w.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ══ PHASES ══ */}
      <section className="phases-section" id="phases">
        <span className="section-tag reveal">The Roadmap</span>
        <h2 className="section-title reveal reveal-delay-1">Four phases.<br /><em>One destination.</em></h2>
        <p className="section-body reveal reveal-delay-2">
          Every phase delivers real milestones, real infrastructure, and real value uplift to every plot in Jungle City.
          This is not a promise — it is a plan.
        </p>
        <div className="phase-timeline">
          {PHASES.map((p,i) => (
            <div key={p.num} className={`phase-item reveal reveal-delay-${i+1}`}>
              <div className="phase-dot" style={{background:p.dot}} />
              <span className="phase-num">{p.num}</span>
              <p className="phase-name">{p.name}</p>
              <p className="phase-desc">{p.desc}</p>
              <p className="phase-time">{p.time}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ══ CTA ══ */}
      <section className="cta-section" id="contact">
        <span className="section-tag reveal" style={{display:'block',textAlign:'center'}}>Get In</span>
        <h2 className="section-title reveal reveal-delay-1">
          The ground floor<br />is <em>open.</em>
        </h2>
        <p className="cta-body reveal reveal-delay-2">
          Phase 1 plots start at ₦9M. Prices increase 30% in Phase 2.
          Leave your details and our team will reach out within 24 hours.
        </p>
        <div className="lead-form reveal reveal-delay-3">
          <input type="text"  className="lead-input" placeholder="Full Name" />
          <input type="tel"   className="lead-input" placeholder="Phone / WhatsApp" />
          <input type="email" className="lead-input" placeholder="Email Address" />
          <select className="lead-select">
            <option value="">I am interested in...</option>
            <option>Small Plot (400sqm) — ₦9M</option>
            <option>Medium Plot (700sqm) — ₦14M</option>
            <option>Large Plot (1,000sqm) — ₦20M</option>
            <option>Accommodation / Retreat Booking</option>
            <option>Becoming an Agent</option>
          </select>
          <button className="btn-primary" style={{width:'100%'}}>Register My Interest →</button>
        </div>
        <p className="privacy-note reveal">Your details are private and will only be used by the Jungle City sales team.</p>
      </section>

      {/* FOOTER */}
      <footer>
        <div>
          <p className="footer-brand">Jungle City</p>
          <p className="footer-tagline">Nigeria's first jungle resort city. Between Lagos, Ogun, and Ibadan. Phase 1 plots available now from ₦9M.</p>
        </div>
        <div className="footer-col">
          <h4>Navigate</h4>
          {['concept','experience','invest','phases','contact'].map(id => (
            <a key={id} href={`#${id}`}>{id.charAt(0).toUpperCase()+id.slice(1)}</a>
          ))}
        </div>
        <div className="footer-col">
          <h4>Opportunities</h4>
          <a href="#invest">Buy a Plot</a>
          <a href="#contact">Book a Retreat</a>
          <a href="#contact">Become an Agent</a>
          <a href="#contact">Corporate Packages</a>
        </div>
      </footer>

      <div className="footer-bottom">
        <p>© 2026 Jungle City · Nigeria · DS2326</p>
        <p>Where the wild becomes a way of life.</p>
      </div>
    </>
  )
}
